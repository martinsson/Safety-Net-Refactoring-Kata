package io.ferrow.connect.sandbox;

/**
 * A fault rule, active from the moment it is created until {@link Sandbox#reset()}, or until it
 * has fired the number of times given to {@link #times(int)}.
 *
 * <p>Narrowing methods ({@code forAccount}, {@code forReference}, ...) restrict the rule to
 * requests about that account, reference, and so on. When several narrowings are given, all must
 * match. When several rules match a request, the oldest one fires.
 *
 * @param <R> the concrete rule type
 */
public abstract class FaultRule<R extends FaultRule<R>> {

    private int remaining = -1;

    FaultRule() {
    }

    /**
     * Limits the rule to the next {@code count} matching requests; after that it no longer fires.
     *
     * @param count how many matching requests fail, positive
     * @return this rule
     */
    public R times(int count) {
        if (count < 1) {
            throw new IllegalArgumentException("count must be positive: " + count);
        }
        remaining = count;
        return self();
    }

    /** @return whether the rule can still fire */
    boolean active() {
        return remaining != 0;
    }

    /** Records that the rule fired once. */
    void fired() {
        if (remaining > 0) {
            remaining--;
        }
    }

    @SuppressWarnings("unchecked")
    private R self() {
        return (R) this;
    }
}
