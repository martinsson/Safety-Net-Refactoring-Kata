package io.ferrow.connect.sandbox;

import java.time.LocalDate;

/**
 * A courier booking accepted by the sandbox.
 *
 * @param trackingId the tracking id ({@code TRK-0001}, {@code TRK-0002}, ...)
 * @param reference the caller's reference
 * @param zone the delivery zone
 * @param date the pick-up date
 * @param parcels the number of parcels
 * @param cancelled whether the booking has been cancelled
 */
public record RecordedBooking(String trackingId, String reference, int zone, LocalDate date, int parcels,
                              boolean cancelled) {
}
