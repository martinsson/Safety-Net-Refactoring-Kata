package io.ferrow.connect.sandbox;

/**
 * A mail accepted by the sandbox.
 *
 * @param to the recipient address
 * @param subject the subject line
 * @param body the text
 */
public record RecordedMail(String to, String subject, String body) {
}
