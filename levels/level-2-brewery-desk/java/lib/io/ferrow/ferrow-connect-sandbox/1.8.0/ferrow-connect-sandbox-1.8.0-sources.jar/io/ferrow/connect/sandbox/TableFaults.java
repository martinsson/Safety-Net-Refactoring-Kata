package io.ferrow.connect.sandbox;

import com.tallowdb.spi.WriteKind;

import java.util.EnumSet;
import java.util.Set;

/** Creates write faults on one TallowDB table. Obtain it with {@link StoreFaults#table(String)}. */
public final class TableFaults {

    private final String database;
    private final String table;

    TableFaults(String database, String table) {
        this.database = database;
        this.table = table;
    }

    /** @return the new rule, active at once: inserts, updates and deletes fail */
    public StoreFault failWrites() {
        return add(EnumSet.allOf(WriteKind.class));
    }

    /** @return the new rule, active at once: inserts fail */
    public StoreFault failInserts() {
        return add(EnumSet.of(WriteKind.INSERT));
    }

    /** @return the new rule, active at once: updates fail */
    public StoreFault failUpdates() {
        return add(EnumSet.of(WriteKind.UPDATE));
    }

    /** @return the new rule, active at once: deletes fail */
    public StoreFault failDeletes() {
        return add(EnumSet.of(WriteKind.DELETE));
    }

    private StoreFault add(Set<WriteKind> kinds) {
        StoreFault rule = new StoreFault(database, table, kinds);
        Sandbox.running().addRule(rule);
        return rule;
    }
}
