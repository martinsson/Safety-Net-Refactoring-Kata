package io.ferrow.connect.sandbox;

/** How a platform fault rule makes a matching request fail. */
public enum FaultKind {
    /** The charge is refused with a {@code DeclinedException}. Charges only. */
    DECLINE,
    /** {@code UnreachableException}; the request is not applied. */
    UNREACHABLE,
    /** {@code TimeoutException}; the request is not applied. */
    TIMEOUT_BEFORE_APPLYING,
    /** {@code TimeoutException}; the request is applied first, only the answer is lost. */
    TIMEOUT_AFTER_APPLYING
}
