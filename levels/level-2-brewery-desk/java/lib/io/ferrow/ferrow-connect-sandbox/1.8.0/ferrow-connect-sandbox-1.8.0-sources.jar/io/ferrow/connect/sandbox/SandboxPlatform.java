package io.ferrow.connect.sandbox;

import com.tallowdb.StoreException;
import com.tallowdb.spi.WriteGuard;
import com.tallowdb.spi.WriteRequest;
import io.ferrow.connect.Booking;
import io.ferrow.connect.Charge;
import io.ferrow.connect.Connect;
import io.ferrow.connect.DeclinedException;
import io.ferrow.connect.NotFoundException;
import io.ferrow.connect.Tariff;
import io.ferrow.connect.TimeoutException;
import io.ferrow.connect.UnreachableException;
import io.ferrow.connect.spi.Platform;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.function.Supplier;

/** The in-memory platform installed by {@link Sandbox}. One instance per reset. */
final class SandboxPlatform implements Platform, WriteGuard {

    private final Map<String, RecordedCharge> charges = new LinkedHashMap<>();
    private final Map<String, RecordedBooking> bookings = new LinkedHashMap<>();
    private final List<RecordedMail> mails = new ArrayList<>();
    private final List<RecordedCall> calls = new ArrayList<>();
    private final List<PlatformFault<?>> platformRules = new ArrayList<>();
    private final List<StoreFault> storeRules = new ArrayList<>();

    void addRule(PlatformFault<?> rule) {
        platformRules.add(rule);
    }

    void addRule(StoreFault rule) {
        storeRules.add(rule);
    }

    List<RecordedCharge> charges() {
        return List.copyOf(charges.values());
    }

    List<RecordedBooking> bookings() {
        return List.copyOf(bookings.values());
    }

    List<RecordedMail> mails() {
        return List.copyOf(mails);
    }

    List<RecordedCall> calls() {
        return List.copyOf(calls);
    }

    @Override
    public Charge charge(String account, long cents, String reference) {
        CallInfo info = new CallInfo("payments", "charge", account, reference, null, null, null);
        return handle(info, account + " " + cents + " " + reference, () -> {
            String id = String.format("ch_%04d", charges.size() + 1);
            charges.put(id, new RecordedCharge(id, account, cents, reference, false));
            return new Charge(id, account, cents, reference);
        });
    }

    @Override
    public void refund(String chargeId) {
        RecordedCharge charge = charges.get(chargeId);
        CallInfo info = new CallInfo("payments", "refund",
                charge == null ? null : charge.account(), charge == null ? null : charge.reference(),
                null, null, null);
        handle(info, chargeId, () -> {
            if (charge == null) {
                throw new NotFoundException("no such charge: " + chargeId);
            }
            charges.put(chargeId, new RecordedCharge(charge.id(), charge.account(), charge.cents(),
                    charge.reference(), true));
            return null;
        });
    }

    @Override
    public long quote(int zone, int kilos) {
        CallInfo info = new CallInfo("courier", "quote", null, null, zone, null, null);
        return handle(info, zone + " " + kilos, () -> Tariff.price(zone, kilos));
    }

    @Override
    public Booking book(String reference, int zone, LocalDate date, int parcels) {
        CallInfo info = new CallInfo("courier", "book", null, reference, zone, null, null);
        return handle(info, reference + " " + zone + " " + date + " " + parcels, () -> {
            String id = String.format("TRK-%04d", bookings.size() + 1);
            bookings.put(id, new RecordedBooking(id, reference, zone, date, parcels, false));
            return new Booking(id, reference, zone, date, parcels);
        });
    }

    @Override
    public void cancel(String trackingId) {
        RecordedBooking booking = bookings.get(trackingId);
        CallInfo info = new CallInfo("courier", "cancel", null,
                booking == null ? null : booking.reference(), booking == null ? null : booking.zone(),
                null, null);
        handle(info, trackingId, () -> {
            if (booking == null) {
                throw new NotFoundException("no such booking: " + trackingId);
            }
            bookings.put(trackingId, new RecordedBooking(booking.trackingId(), booking.reference(),
                    booking.zone(), booking.date(), booking.parcels(), true));
            return null;
        });
    }

    @Override
    public void send(String to, String subject, String body) {
        CallInfo info = new CallInfo("mail", "send", null, null, null, to, subject);
        handle(info, to + " " + subject, () -> {
            mails.add(new RecordedMail(to, subject, body));
            return null;
        });
    }

    @Override
    public void beforeWrite(WriteRequest write) {
        for (Iterator<StoreFault> it = storeRules.iterator(); it.hasNext(); ) {
            StoreFault rule = it.next();
            if (rule.matches(write)) {
                rule.fired();
                if (!rule.active()) {
                    it.remove();
                }
                throw new StoreException("write failed on " + write.database() + "." + write.table()
                        + " (" + write.kind().name().toLowerCase() + ")");
            }
        }
    }

    private <T> T handle(CallInfo info, String arguments, Supplier<T> apply) {
        String operation = info.service() + "." + info.operation();
        Optional<PlatformFault<?>> fault = takeFault(info);
        if (fault.isPresent()) {
            switch (fault.get().kind()) {
                case DECLINE -> {
                    calls.add(new RecordedCall(operation, arguments, Outcome.DECLINED));
                    throw new DeclinedException("charge declined for account " + info.account());
                }
                case UNREACHABLE -> {
                    calls.add(new RecordedCall(operation, arguments, Outcome.UNREACHABLE));
                    throw new UnreachableException(Connect.ENDPOINT + " unreachable");
                }
                case TIMEOUT_BEFORE_APPLYING -> {
                    calls.add(new RecordedCall(operation, arguments, Outcome.TIMEOUT_BEFORE_APPLYING));
                    throw timeout(operation);
                }
                case TIMEOUT_AFTER_APPLYING -> {
                    try {
                        apply.get();
                    } catch (NotFoundException answerLost) {
                        // the platform answered, but the answer never reached the caller
                    }
                    calls.add(new RecordedCall(operation, arguments, Outcome.TIMEOUT_AFTER_APPLYING));
                    throw timeout(operation);
                }
            }
        }
        try {
            T result = apply.get();
            calls.add(new RecordedCall(operation, arguments, Outcome.OK));
            return result;
        } catch (NotFoundException notFound) {
            calls.add(new RecordedCall(operation, arguments, Outcome.NOT_FOUND));
            throw notFound;
        }
    }

    private Optional<PlatformFault<?>> takeFault(CallInfo info) {
        for (Iterator<PlatformFault<?>> it = platformRules.iterator(); it.hasNext(); ) {
            PlatformFault<?> rule = it.next();
            if (rule.matches(info)) {
                rule.fired();
                if (!rule.active()) {
                    it.remove();
                }
                return Optional.of(rule);
            }
        }
        return Optional.empty();
    }

    private static TimeoutException timeout(String operation) {
        return new TimeoutException(Connect.ENDPOINT + " did not answer " + operation + " in time");
    }
}
