package io.ferrow.connect.sandbox;

/**
 * Creates write faults on a TallowDB database. Obtain it with {@link Sandbox#store(String)}.
 *
 * <pre>{@code
 * Sandbox.store("cellar").table("orders").failWrites();
 * Sandbox.store("cellar").table("stock").failUpdates().where("sku", "IPA-30").times(1);
 * }</pre>
 */
public final class StoreFaults {

    private final String database;

    StoreFaults(String database) {
        this.database = database;
    }

    /**
     * @param table the table name
     * @return a selector of write faults on that table
     */
    public TableFaults table(String table) {
        return new TableFaults(database, table);
    }
}
