package io.ferrow.connect.sandbox;

import java.util.Objects;
import java.util.Set;

/** A fault rule on mail requests. */
public final class MailFault extends PlatformFault<MailFault> {

    private String recipient;
    private String subjectPart;

    MailFault(FaultKind kind) {
        super("mail", Set.of(), kind);
    }

    /**
     * @param recipient only mails to this address
     * @return this rule
     */
    public MailFault forRecipient(String recipient) {
        this.recipient = Objects.requireNonNull(recipient, "recipient");
        return this;
    }

    /**
     * @param text only mails whose subject contains this text
     * @return this rule
     */
    public MailFault forSubjectContaining(String text) {
        this.subjectPart = Objects.requireNonNull(text, "text");
        return this;
    }

    @Override
    boolean matchesContent(CallInfo call) {
        return wanted(recipient, call.recipient())
                && (subjectPart == null || call.subject() != null && call.subject().contains(subjectPart));
    }
}
