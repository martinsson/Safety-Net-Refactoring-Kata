package io.ferrow.connect.sandbox;

import com.tallowdb.spi.WriteGuards;
import io.ferrow.connect.spi.Platforms;

import java.util.List;
import java.util.Set;

/**
 * The official Ferrow Connect test kit: a deterministic, in-memory platform installed behind
 * {@link io.ferrow.connect.Connect} for the whole JVM.
 *
 * <pre>{@code
 * Sandbox.start();
 * Sandbox.payments().decline().forAccount("CAFE-0012");
 * // ... run code that uses Connect.payments(), Connect.courier(), Connect.mail()
 * assertEquals(1, Sandbox.charges().size());
 * }</pre>
 *
 * <p>The sandbox accepts every request unless a fault rule says otherwise, and records what it
 * accepted. Ids are {@code ch_0001}, {@code ch_0002}, ... for charges and {@code TRK-0001}, ...
 * for bookings, counted from the last reset. Quotes follow the published
 * {@link io.ferrow.connect.Tariff}. Nothing depends on the clock, on threads or on randomness.
 *
 * <p>The sandbox can also make TallowDB writes fail, see {@link #store(String)}. It does not
 * create, empty or drop databases; use {@code TallowDb.dropAll()} for that.
 */
public final class Sandbox {

    private static SandboxPlatform platform;

    private Sandbox() {
    }

    /**
     * Installs a fresh sandbox behind {@code Connect} and behind TallowDB writes. Same as
     * {@link #reset()}.
     */
    public static void start() {
        reset();
    }

    /**
     * Replaces the sandbox with a fresh one: no records, no fault rules, ids counted from 1 again.
     * Installs it if it was not running.
     */
    public static void reset() {
        platform = new SandboxPlatform();
        Platforms.bind(platform);
        WriteGuards.install(platform);
    }

    /**
     * Removes the sandbox: {@code Connect} calls go to the remote platform again, and TallowDB
     * writes are no longer checked. Records are discarded.
     */
    public static void stop() {
        platform = null;
        Platforms.unbind();
        WriteGuards.clear();
    }

    /** @return whether the sandbox is installed */
    public static boolean isRunning() {
        return platform != null;
    }

    /** @return the charges accepted since the last reset, in id order, with their refunded flag */
    public static List<RecordedCharge> charges() {
        return running().charges();
    }

    /** @return the bookings accepted since the last reset, in id order, with their cancelled flag */
    public static List<RecordedBooking> bookings() {
        return running().bookings();
    }

    /** @return the mails accepted since the last reset, in the order they were sent */
    public static List<RecordedMail> mails() {
        return running().mails();
    }

    /** @return every request received since the last reset, with its outcome, in order */
    public static List<RecordedCall> calls() {
        return running().calls();
    }

    /** @return a selector to create fault rules on payment requests */
    public static PaymentFaults payments() {
        running();
        return new PaymentFaults(Set.of());
    }

    /** @return a selector to create fault rules on courier requests */
    public static CourierFaults courier() {
        running();
        return new CourierFaults(Set.of());
    }

    /** @return a selector to create fault rules on mail requests */
    public static MailFaults mail() {
        running();
        return new MailFaults();
    }

    /**
     * @param database the TallowDB database name
     * @return a selector to create write faults on that database
     */
    public static StoreFaults store(String database) {
        running();
        return new StoreFaults(database);
    }

    static SandboxPlatform running() {
        if (platform == null) {
            throw new IllegalStateException("the sandbox is not running: call Sandbox.start() first");
        }
        return platform;
    }
}
