package io.ferrow.connect.sandbox;

import java.util.Set;

/**
 * Creates fault rules on payment requests. Obtain it with {@link Sandbox#payments()}.
 *
 * <pre>{@code
 * Sandbox.payments().decline().forAccount("CAFE-0012");
 * Sandbox.payments().refund().unreachable();
 * Sandbox.payments().charge().timeoutAfterApplying().forReference("SO-1001").times(1);
 * }</pre>
 */
public final class PaymentFaults {

    private final Set<String> operations;

    PaymentFaults(Set<String> operations) {
        this.operations = operations;
    }

    /** @return a selector restricted to {@code charge} requests */
    public PaymentFaults charge() {
        return new PaymentFaults(Set.of("charge"));
    }

    /** @return a selector restricted to {@code refund} requests */
    public PaymentFaults refund() {
        return new PaymentFaults(Set.of("refund"));
    }

    /**
     * Refuses matching charges with a {@code DeclinedException}. Applies to charges only.
     *
     * @return the new rule, active at once
     */
    public PaymentFault decline() {
        if (operations.contains("refund")) {
            throw new IllegalStateException("only charges can be declined");
        }
        return add(new PaymentFault(Set.of("charge"), FaultKind.DECLINE));
    }

    /** @return the new rule, active at once: matching requests are unreachable */
    public PaymentFault unreachable() {
        return add(new PaymentFault(operations, FaultKind.UNREACHABLE));
    }

    /** @return the new rule, active at once: matching requests time out without being applied */
    public PaymentFault timeoutBeforeApplying() {
        return add(new PaymentFault(operations, FaultKind.TIMEOUT_BEFORE_APPLYING));
    }

    /** @return the new rule, active at once: matching requests are applied, then time out */
    public PaymentFault timeoutAfterApplying() {
        return add(new PaymentFault(operations, FaultKind.TIMEOUT_AFTER_APPLYING));
    }

    private static PaymentFault add(PaymentFault rule) {
        Sandbox.running().addRule(rule);
        return rule;
    }
}
