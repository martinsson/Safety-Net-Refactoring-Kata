package io.ferrow.connect.sandbox;

import java.util.Objects;
import java.util.Set;

/**
 * A fault rule on platform requests. See {@link PaymentFault}, {@link CourierFault} and
 * {@link MailFault} for the narrowings each service offers.
 *
 * @param <R> the concrete rule type
 */
public abstract class PlatformFault<R extends PlatformFault<R>> extends FaultRule<R> {

    private final String service;
    private final Set<String> operations;
    private final FaultKind kind;

    PlatformFault(String service, Set<String> operations, FaultKind kind) {
        this.service = service;
        this.operations = operations;
        this.kind = kind;
    }

    /** @return how matching requests fail */
    public FaultKind kind() {
        return kind;
    }

    boolean matches(CallInfo call) {
        return active() && service.equals(call.service())
                && (operations.isEmpty() || operations.contains(call.operation()))
                && matchesContent(call);
    }

    abstract boolean matchesContent(CallInfo call);

    static boolean wanted(Object expected, Object actual) {
        return expected == null || Objects.equals(expected, actual);
    }
}
