package io.ferrow.connect.sandbox;

/** What the sandbox did with a request. */
public enum Outcome {
    /** Applied and answered. */
    OK,
    /** Charge refused with a {@code DeclinedException}; nothing applied. */
    DECLINED,
    /** The charge or booking does not exist; {@code NotFoundException}; nothing applied. */
    NOT_FOUND,
    /** {@code UnreachableException}; nothing applied. */
    UNREACHABLE,
    /** {@code TimeoutException}; nothing applied. */
    TIMEOUT_BEFORE_APPLYING,
    /** {@code TimeoutException}; the request was applied (and recorded) all the same. */
    TIMEOUT_AFTER_APPLYING
}
