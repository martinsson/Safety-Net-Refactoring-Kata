package io.ferrow.connect.sandbox;

/**
 * One request received by the sandbox, whatever its outcome.
 *
 * @param operation {@code payments.charge}, {@code payments.refund}, {@code courier.quote},
 *                  {@code courier.book}, {@code courier.cancel} or {@code mail.send}
 * @param arguments the arguments, space-separated (for a mail, the recipient and the subject)
 * @param outcome what the sandbox did with it
 */
public record RecordedCall(String operation, String arguments, Outcome outcome) {

    /** @return {@code operation arguments -> OUTCOME} */
    @Override
    public String toString() {
        return operation + " " + arguments + " -> " + outcome;
    }
}
