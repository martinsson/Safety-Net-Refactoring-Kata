package io.ferrow.connect.sandbox;

import java.util.Objects;
import java.util.Set;

/**
 * A fault rule on courier requests. A cancel matches through the booking it names; a quote has
 * no reference, so a rule narrowed with {@link #forReference(String)} never matches a quote.
 */
public final class CourierFault extends PlatformFault<CourierFault> {

    private String reference;
    private Integer zone;

    CourierFault(Set<String> operations, FaultKind kind) {
        super("courier", operations, kind);
    }

    /**
     * @param reference only requests about this shipment reference
     * @return this rule
     */
    public CourierFault forReference(String reference) {
        this.reference = Objects.requireNonNull(reference, "reference");
        return this;
    }

    /**
     * @param zone only requests about this delivery zone
     * @return this rule
     */
    public CourierFault forZone(int zone) {
        this.zone = zone;
        return this;
    }

    @Override
    boolean matchesContent(CallInfo call) {
        return wanted(reference, call.reference()) && wanted(zone, call.zone());
    }
}
