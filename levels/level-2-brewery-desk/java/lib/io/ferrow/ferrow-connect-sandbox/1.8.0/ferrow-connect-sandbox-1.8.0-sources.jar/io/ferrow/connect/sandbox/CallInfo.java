package io.ferrow.connect.sandbox;

/**
 * What a request is about, as fault rules see it. Fields that do not apply are {@code null}.
 * For a refund or a cancel, account, reference and zone are those of the charge or booking
 * named in the request.
 */
record CallInfo(String service, String operation, String account, String reference, Integer zone,
                String recipient, String subject) {
}
