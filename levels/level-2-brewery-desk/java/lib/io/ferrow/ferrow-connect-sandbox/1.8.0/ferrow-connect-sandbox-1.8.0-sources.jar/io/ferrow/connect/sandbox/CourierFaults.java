package io.ferrow.connect.sandbox;

import java.util.Set;

/**
 * Creates fault rules on courier requests. Obtain it with {@link Sandbox#courier()}.
 *
 * <pre>{@code
 * Sandbox.courier().unreachable().forZone(4);
 * Sandbox.courier().book().timeoutAfterApplying().forReference("SO-1001");
 * }</pre>
 */
public final class CourierFaults {

    private final Set<String> operations;

    CourierFaults(Set<String> operations) {
        this.operations = operations;
    }

    /** @return a selector restricted to {@code quote} requests */
    public CourierFaults quote() {
        return new CourierFaults(Set.of("quote"));
    }

    /** @return a selector restricted to {@code book} requests */
    public CourierFaults book() {
        return new CourierFaults(Set.of("book"));
    }

    /** @return a selector restricted to {@code cancel} requests */
    public CourierFaults cancel() {
        return new CourierFaults(Set.of("cancel"));
    }

    /** @return the new rule, active at once: matching requests are unreachable */
    public CourierFault unreachable() {
        return add(new CourierFault(operations, FaultKind.UNREACHABLE));
    }

    /** @return the new rule, active at once: matching requests time out without being applied */
    public CourierFault timeoutBeforeApplying() {
        return add(new CourierFault(operations, FaultKind.TIMEOUT_BEFORE_APPLYING));
    }

    /** @return the new rule, active at once: matching requests are applied, then time out */
    public CourierFault timeoutAfterApplying() {
        return add(new CourierFault(operations, FaultKind.TIMEOUT_AFTER_APPLYING));
    }

    private static CourierFault add(CourierFault rule) {
        Sandbox.running().addRule(rule);
        return rule;
    }
}
