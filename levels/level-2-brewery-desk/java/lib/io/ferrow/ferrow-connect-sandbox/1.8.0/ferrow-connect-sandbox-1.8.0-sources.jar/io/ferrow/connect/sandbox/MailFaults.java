package io.ferrow.connect.sandbox;

/**
 * Creates fault rules on mail requests. Obtain it with {@link Sandbox#mail()}.
 *
 * <pre>{@code
 * Sandbox.mail().unreachable();
 * Sandbox.mail().timeoutAfterApplying().forRecipient("orders@cafe.example");
 * }</pre>
 */
public final class MailFaults {

    MailFaults() {
    }

    /** @return the new rule, active at once: matching mails are unreachable */
    public MailFault unreachable() {
        return add(new MailFault(FaultKind.UNREACHABLE));
    }

    /** @return the new rule, active at once: matching mails time out without being sent */
    public MailFault timeoutBeforeApplying() {
        return add(new MailFault(FaultKind.TIMEOUT_BEFORE_APPLYING));
    }

    /** @return the new rule, active at once: matching mails are sent, then time out */
    public MailFault timeoutAfterApplying() {
        return add(new MailFault(FaultKind.TIMEOUT_AFTER_APPLYING));
    }

    private static MailFault add(MailFault rule) {
        Sandbox.running().addRule(rule);
        return rule;
    }
}
