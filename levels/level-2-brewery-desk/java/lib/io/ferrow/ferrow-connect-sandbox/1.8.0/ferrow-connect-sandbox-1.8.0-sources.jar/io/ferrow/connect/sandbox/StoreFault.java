package io.ferrow.connect.sandbox;

import com.tallowdb.spi.WriteKind;
import com.tallowdb.spi.WriteRequest;

import java.util.Objects;
import java.util.Set;

/**
 * A write fault on a TallowDB table: matching writes throw {@code StoreException} and are not
 * applied. Sequences are never affected.
 */
public final class StoreFault extends FaultRule<StoreFault> {

    private final String database;
    private final String table;
    private final Set<WriteKind> kinds;
    private String column;
    private Object value;

    StoreFault(String database, String table, Set<WriteKind> kinds) {
        this.database = database;
        this.table = table;
        this.kinds = kinds;
    }

    /**
     * Restricts the rule to writes about rows where the column has that value: either the value
     * being written, or the value the row holds before the write.
     *
     * @param column the column name
     * @param value the value, as it would be inserted
     * @return this rule
     */
    public StoreFault where(String column, Object value) {
        this.column = Objects.requireNonNull(column, "column");
        this.value = normalize(Objects.requireNonNull(value, "value"));
        return this;
    }

    boolean matches(WriteRequest write) {
        return active() && database.equals(write.database()) && table.equals(write.table())
                && kinds.contains(write.kind()) && matchesRow(write);
    }

    private boolean matchesRow(WriteRequest write) {
        if (column == null) {
            return true;
        }
        return value.equals(write.values().get(column))
                || write.existing() != null && value.equals(write.existing().get(column));
    }

    private static Object normalize(Object value) {
        if (value instanceof Integer || value instanceof Short || value instanceof Byte) {
            return ((Number) value).longValue();
        }
        return value;
    }
}
