package io.ferrow.connect.sandbox;

import java.util.Objects;
import java.util.Set;

/** A fault rule on payment requests. A refund matches through the charge it names. */
public final class PaymentFault extends PlatformFault<PaymentFault> {

    private String account;
    private String reference;

    PaymentFault(Set<String> operations, FaultKind kind) {
        super("payments", operations, kind);
    }

    /**
     * @param account only requests about this customer account
     * @return this rule
     */
    public PaymentFault forAccount(String account) {
        this.account = Objects.requireNonNull(account, "account");
        return this;
    }

    /**
     * @param reference only requests about this reference
     * @return this rule
     */
    public PaymentFault forReference(String reference) {
        this.reference = Objects.requireNonNull(reference, "reference");
        return this;
    }

    @Override
    boolean matchesContent(CallInfo call) {
        return wanted(account, call.account()) && wanted(reference, call.reference());
    }
}
