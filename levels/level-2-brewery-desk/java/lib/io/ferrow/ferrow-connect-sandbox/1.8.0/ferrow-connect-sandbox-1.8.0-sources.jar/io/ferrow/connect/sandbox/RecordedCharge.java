package io.ferrow.connect.sandbox;

/**
 * A charge accepted by the sandbox.
 *
 * @param id the charge id ({@code ch_0001}, {@code ch_0002}, ...)
 * @param account the customer account
 * @param cents the amount, in cents
 * @param reference the caller's reference
 * @param refunded whether the charge has been refunded
 */
public record RecordedCharge(String id, String account, long cents, String reference, boolean refunded) {
}
