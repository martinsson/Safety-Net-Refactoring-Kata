package io.ferrow.connect;

/**
 * The platform did not answer in time. A timeout says nothing about the request: it may or may
 * not have been applied.
 */
public class TimeoutException extends RemoteException {

    /** @param message what happened */
    public TimeoutException(String message) {
        super(message);
    }
}
