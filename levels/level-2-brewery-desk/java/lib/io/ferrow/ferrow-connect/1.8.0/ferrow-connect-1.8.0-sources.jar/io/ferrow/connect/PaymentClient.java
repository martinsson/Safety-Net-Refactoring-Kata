package io.ferrow.connect;

import io.ferrow.connect.spi.Platforms;

/** Client of the payment service. Obtain it with {@link Connect#payments()}. */
public final class PaymentClient {

    PaymentClient() {
    }

    /**
     * Charges a customer account.
     *
     * @param account the customer account, for example {@code "CAFE-0012"}
     * @param cents the amount, in cents, positive
     * @param reference your reference, for example an order number
     * @return the accepted charge
     * @throws DeclinedException if the platform refuses the charge
     * @throws RemoteException if the platform cannot be reached or does not answer in time
     */
    public Charge charge(String account, long cents, String reference) {
        Validation.text("account", account);
        Validation.positive("cents", cents);
        Validation.text("reference", reference);
        return Platforms.current().charge(account, cents, reference);
    }

    /**
     * Refunds a charge in full. Refunds are idempotent: refunding a charge that is already
     * refunded succeeds and changes nothing.
     *
     * @param chargeId the id of the charge
     * @throws NotFoundException if there is no such charge
     * @throws RemoteException if the platform cannot be reached or does not answer in time
     */
    public void refund(String chargeId) {
        Validation.text("chargeId", chargeId);
        Platforms.current().refund(chargeId);
    }
}
