package io.ferrow.connect;

import io.ferrow.connect.spi.Platforms;

import java.time.LocalDate;
import java.util.Objects;

/** Client of the courier service. Obtain it with {@link Connect#courier()}. */
public final class CourierClient {

    CourierClient() {
    }

    /**
     * Asks the platform for the price of a shipment. The answer follows the published
     * {@link Tariff}.
     *
     * @param zone the delivery zone, 1 to 5
     * @param kilos the total weight in kilos, 1 to 1000
     * @return the price in cents
     * @throws RemoteException if the platform cannot be reached or does not answer in time
     */
    public long quote(int zone, int kilos) {
        Tariff.price(zone, kilos);
        return Platforms.current().quote(zone, kilos);
    }

    /**
     * Books a pick-up.
     *
     * @param reference your reference for the shipment
     * @param zone the delivery zone, 1 to 5
     * @param date the pick-up date
     * @param parcels the number of parcels, positive
     * @return the accepted booking, with its tracking id
     * @throws RemoteException if the platform cannot be reached or does not answer in time
     */
    public Booking book(String reference, int zone, LocalDate date, int parcels) {
        Validation.text("reference", reference);
        Validation.zone(zone);
        Objects.requireNonNull(date, "date");
        Validation.positive("parcels", parcels);
        return Platforms.current().book(reference, zone, date, parcels);
    }

    /**
     * Cancels a booking. Cancelling a booking that is already cancelled succeeds and changes
     * nothing.
     *
     * @param trackingId the tracking id of the booking
     * @throws NotFoundException if there is no such booking
     * @throws RemoteException if the platform cannot be reached or does not answer in time
     */
    public void cancel(String trackingId) {
        Validation.text("trackingId", trackingId);
        Platforms.current().cancel(trackingId);
    }
}
