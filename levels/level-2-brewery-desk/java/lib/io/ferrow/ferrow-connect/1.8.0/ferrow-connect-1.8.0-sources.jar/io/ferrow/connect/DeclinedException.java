package io.ferrow.connect;

/** The platform refused a charge. This is a business answer: nothing was charged. */
public class DeclinedException extends FerrowException {

    /** @param message why the charge was refused */
    public DeclinedException(String message) {
        super(message);
    }
}
