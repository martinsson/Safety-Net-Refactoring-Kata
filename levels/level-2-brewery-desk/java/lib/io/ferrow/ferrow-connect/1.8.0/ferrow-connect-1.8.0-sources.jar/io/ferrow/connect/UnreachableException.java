package io.ferrow.connect;

/** The platform could not be reached. The request was not applied. */
public class UnreachableException extends RemoteException {

    /** @param message what happened */
    public UnreachableException(String message) {
        super(message);
    }
}
