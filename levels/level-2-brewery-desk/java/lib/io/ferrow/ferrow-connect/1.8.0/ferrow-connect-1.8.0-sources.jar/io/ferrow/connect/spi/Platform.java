package io.ferrow.connect.spi;

import io.ferrow.connect.Booking;
import io.ferrow.connect.Charge;

import java.time.LocalDate;

/**
 * What the clients talk to. The default platform is the remote one at
 * {@value io.ferrow.connect.Connect#ENDPOINT}; test kits bind another one with
 * {@link Platforms#bind(Platform)}. Arguments are already validated by the clients.
 */
public interface Platform {

    /** @see io.ferrow.connect.PaymentClient#charge(String, long, String) */
    Charge charge(String account, long cents, String reference);

    /** @see io.ferrow.connect.PaymentClient#refund(String) */
    void refund(String chargeId);

    /** @see io.ferrow.connect.CourierClient#quote(int, int) */
    long quote(int zone, int kilos);

    /** @see io.ferrow.connect.CourierClient#book(String, int, LocalDate, int) */
    Booking book(String reference, int zone, LocalDate date, int parcels);

    /** @see io.ferrow.connect.CourierClient#cancel(String) */
    void cancel(String trackingId);

    /** @see io.ferrow.connect.MailClient#send(String, String, String) */
    void send(String to, String subject, String body);
}
