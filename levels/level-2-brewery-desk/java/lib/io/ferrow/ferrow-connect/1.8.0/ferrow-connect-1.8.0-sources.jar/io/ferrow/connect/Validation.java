package io.ferrow.connect;

/** Argument checks done by the clients before sending a request. */
final class Validation {

    private Validation() {
    }

    static String text(String name, String value) {
        if (value == null || value.isBlank()) {
            throw new IllegalArgumentException(name + " must not be blank");
        }
        return value;
    }

    static void positive(String name, long value) {
        if (value <= 0) {
            throw new IllegalArgumentException(name + " must be positive: " + value);
        }
    }

    static void zone(int zone) {
        if (zone < 1 || zone > Tariff.MAX_ZONE) {
            throw new IllegalArgumentException("zone must be between 1 and " + Tariff.MAX_ZONE + ": " + zone);
        }
    }
}
