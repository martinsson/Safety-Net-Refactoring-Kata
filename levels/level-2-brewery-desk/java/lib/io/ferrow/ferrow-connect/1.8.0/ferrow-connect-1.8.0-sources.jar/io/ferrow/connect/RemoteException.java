package io.ferrow.connect;

/**
 * The call did not get a business answer from the platform: the platform could not be reached,
 * or did not answer in time. See the subclasses.
 */
public class RemoteException extends FerrowException {

    /** @param message what happened */
    public RemoteException(String message) {
        super(message);
    }
}
