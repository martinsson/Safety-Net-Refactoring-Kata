package io.ferrow.connect;

/** Base class of every exception thrown by Ferrow Connect. All are unchecked. */
public class FerrowException extends RuntimeException {

    /** @param message what happened */
    public FerrowException(String message) {
        super(message);
    }
}
