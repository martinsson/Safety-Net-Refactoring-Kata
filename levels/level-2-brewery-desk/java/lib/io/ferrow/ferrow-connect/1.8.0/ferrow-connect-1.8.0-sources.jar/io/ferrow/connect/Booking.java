package io.ferrow.connect;

import java.time.LocalDate;

/**
 * A courier booking accepted by the platform.
 *
 * @param trackingId the tracking id, used to cancel the booking
 * @param reference your reference for the shipment
 * @param zone the delivery zone, 1 to 5
 * @param date the pick-up date
 * @param parcels the number of parcels
 */
public record Booking(String trackingId, String reference, int zone, LocalDate date, int parcels) {
}
