package io.ferrow.connect;

import io.ferrow.connect.spi.Platforms;

import java.util.Objects;

/** Client of the mail service. Obtain it with {@link Connect#mail()}. */
public final class MailClient {

    MailClient() {
    }

    /**
     * Sends a plain-text mail.
     *
     * @param to the recipient address
     * @param subject the subject line
     * @param body the text of the mail
     * @throws RemoteException if the platform cannot be reached or does not answer in time
     */
    public void send(String to, String subject, String body) {
        Validation.text("to", to);
        Validation.text("subject", subject);
        Objects.requireNonNull(body, "body");
        Platforms.current().send(to, subject, body);
    }
}
