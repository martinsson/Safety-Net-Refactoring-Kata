package io.ferrow.connect;

/**
 * The published courier tariff. {@link CourierClient#quote(int, int)} answers with this price.
 *
 * <p>price in cents = {@value #BASE_CENTS} + {@value #PER_ZONE_CENTS} &times; zone
 * + {@value #PER_KILO_CENTS} &times; kilos
 */
public final class Tariff {

    /** Fixed part of every shipment, in cents. */
    public static final long BASE_CENTS = 300;
    /** Price per zone number, in cents. */
    public static final long PER_ZONE_CENTS = 150;
    /** Price per kilo, in cents. */
    public static final long PER_KILO_CENTS = 60;
    /** Highest delivery zone. Zones are numbered from 1. */
    public static final int MAX_ZONE = 5;
    /** Heaviest shipment accepted, in kilos. */
    public static final int MAX_KILOS = 1000;

    private Tariff() {
    }

    /**
     * Computes the price of a shipment.
     *
     * @param zone the delivery zone, 1 to {@value #MAX_ZONE}
     * @param kilos the total weight, 1 to {@value #MAX_KILOS}
     * @return the price in cents
     * @throws IllegalArgumentException if the zone or the weight is out of range
     */
    public static long price(int zone, int kilos) {
        Validation.zone(zone);
        if (kilos < 1 || kilos > MAX_KILOS) {
            throw new IllegalArgumentException("kilos must be between 1 and " + MAX_KILOS + ": " + kilos);
        }
        return BASE_CENTS + PER_ZONE_CENTS * zone + PER_KILO_CENTS * kilos;
    }
}
