package io.ferrow.connect;

/**
 * A charge accepted by the platform.
 *
 * @param id the charge id, used to refund it
 * @param account the customer account charged
 * @param cents the amount, in cents
 * @param reference your reference for the charge
 */
public record Charge(String id, String account, long cents, String reference) {
}
