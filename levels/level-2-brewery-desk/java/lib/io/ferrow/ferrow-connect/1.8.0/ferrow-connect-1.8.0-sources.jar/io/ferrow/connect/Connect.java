package io.ferrow.connect;

/**
 * Entry point of Ferrow Connect: hands out the clients of the platform services.
 *
 * <pre>{@code
 * Charge charge = Connect.payments().charge("CAFE-0012", 4_250, "SO-1001");
 * }</pre>
 *
 * <p>Clients are cheap and stateless; obtaining one never contacts the platform. Each call reads
 * the global configuration at the time it is made and sends one request to
 * {@value #ENDPOINT}. Calls fail with {@link UnreachableException} when the platform cannot be
 * reached, which is always the case from a machine without platform access; use the
 * {@code ferrow-connect-sandbox} test kit there.
 */
public final class Connect {

    /** The platform host. */
    public static final String ENDPOINT = "api.ferrow.example";

    /** The version of this library. */
    public static final String VERSION = "1.8.0";

    private Connect() {
    }

    /** @return a client of the payment service */
    public static PaymentClient payments() {
        return new PaymentClient();
    }

    /** @return a client of the courier service */
    public static CourierClient courier() {
        return new CourierClient();
    }

    /** @return a client of the mail service */
    public static MailClient mail() {
        return new MailClient();
    }
}
