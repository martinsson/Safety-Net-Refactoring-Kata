package io.ferrow.connect;

/** The charge or booking named in the request does not exist on the platform. */
public class NotFoundException extends FerrowException {

    /** @param message what was not found */
    public NotFoundException(String message) {
        super(message);
    }
}
