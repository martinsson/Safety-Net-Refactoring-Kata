package io.ferrow.connect.spi;

import io.ferrow.connect.Booking;
import io.ferrow.connect.Charge;
import io.ferrow.connect.Connect;
import io.ferrow.connect.UnreachableException;

import java.time.LocalDate;
import java.util.Objects;

/** Holds the JVM-wide {@link Platform} that every client call goes to. */
public final class Platforms {

    private static final Platform REMOTE = new RemotePlatform();
    private static Platform current = REMOTE;

    private Platforms() {
    }

    /** @return the platform client calls go to now */
    public static Platform current() {
        return current;
    }

    /**
     * Sends every client call, including calls on clients obtained earlier, to that platform.
     *
     * @param platform the platform
     */
    public static void bind(Platform platform) {
        current = Objects.requireNonNull(platform, "platform");
    }

    /** Sends client calls to the remote platform again. */
    public static void unbind() {
        current = REMOTE;
    }

    /** The remote platform, as seen from a machine without platform access. */
    private static final class RemotePlatform implements Platform {

        private static UnreachableException unreachable() {
            return new UnreachableException(Connect.ENDPOINT + " unreachable");
        }

        @Override
        public Charge charge(String account, long cents, String reference) {
            throw unreachable();
        }

        @Override
        public void refund(String chargeId) {
            throw unreachable();
        }

        @Override
        public long quote(int zone, int kilos) {
            throw unreachable();
        }

        @Override
        public Booking book(String reference, int zone, LocalDate date, int parcels) {
            throw unreachable();
        }

        @Override
        public void cancel(String trackingId) {
            throw unreachable();
        }

        @Override
        public void send(String to, String subject, String body) {
            throw unreachable();
        }
    }
}
