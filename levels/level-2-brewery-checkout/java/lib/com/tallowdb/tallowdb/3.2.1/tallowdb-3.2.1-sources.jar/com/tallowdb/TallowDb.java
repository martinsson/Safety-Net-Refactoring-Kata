package com.tallowdb;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Objects;

/**
 * Entry point of TallowDB, the embedded in-memory table store.
 *
 * <p>Databases live in a registry shared by the whole JVM: {@link #open(String)} returns the same
 * {@link Database} instance for a given name until it is dropped. Data is kept in memory only and
 * disappears when the JVM stops.
 *
 * <pre>{@code
 * Database cellar = TallowDb.open("cellar");
 * long id = cellar.table("kegs").insert(Map.of("sku", "IPA-30", "litres", 30));
 * }</pre>
 *
 * <p>TallowDB is not thread-safe: use a database from one thread at a time.
 */
public final class TallowDb {

    /** The version of this library. */
    public static final String VERSION = "3.2.1";

    private static final Map<String, Database> DATABASES = new LinkedHashMap<>();

    private TallowDb() {
    }

    /**
     * Returns the database of that name, creating it empty on first use.
     *
     * @param name the database name, not blank
     * @return the same instance for the same name, until {@link #drop(String)} or {@link #dropAll()}
     */
    public static Database open(String name) {
        Objects.requireNonNull(name, "name");
        if (name.isBlank()) {
            throw new IllegalArgumentException("database name must not be blank");
        }
        return DATABASES.computeIfAbsent(name, Database::new);
    }

    /**
     * Drops the database of that name, if it exists. A later {@link #open(String)} returns a new,
     * empty database. Instances obtained before the drop keep their data but are no longer
     * registered.
     *
     * @param name the database name
     */
    public static void drop(String name) {
        DATABASES.remove(name);
    }

    /**
     * Drops every database of this JVM. Mostly useful between tests.
     */
    public static void dropAll() {
        DATABASES.clear();
    }
}
