package com.tallowdb.spi;

import com.tallowdb.Row;

import java.util.Collections;
import java.util.Map;
import java.util.TreeMap;

/**
 * A write about to be applied, as seen by a {@link WriteGuard}.
 *
 * @param database the database name
 * @param table the table name
 * @param kind insert, update or delete
 * @param id the id of the row written; for an insert, the id the row will get
 * @param values the values written (all values for an insert, the changed ones for an update,
 *               where {@code null} removes a column; empty for a delete)
 * @param existing the row before the write, or {@code null} for an insert
 */
public record WriteRequest(String database, String table, WriteKind kind, long id,
                           Map<String, Object> values, Row existing) {

    /** Makes an unmodifiable copy of the values. */
    public WriteRequest {
        values = Collections.unmodifiableMap(new TreeMap<>(values));
    }
}
