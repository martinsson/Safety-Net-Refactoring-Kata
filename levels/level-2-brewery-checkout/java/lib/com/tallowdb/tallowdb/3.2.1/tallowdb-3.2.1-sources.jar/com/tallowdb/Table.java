package com.tallowdb;

import com.tallowdb.spi.WriteGuards;
import com.tallowdb.spi.WriteKind;
import com.tallowdb.spi.WriteRequest;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.TreeMap;

/**
 * A table of rows. Each row has a generated {@code long} id and a set of named columns.
 *
 * <p>Ids start at 1 and are never reused, even after a delete. Column values may be
 * {@link String}, {@link Long} (an {@link Integer} is stored as a {@code Long}),
 * {@link Boolean} or {@link LocalDate}. A {@code null} value means the column is absent.
 *
 * <p>Rows are returned as copies: changing what you read never changes the table. Every write is
 * applied at once; there is no transaction to commit or roll back. A write may fail with a
 * {@link StoreException}, in which case nothing was written by that call.
 */
public final class Table {

    private final String database;
    private final String name;
    private final TreeMap<Long, Map<String, Object>> rows = new TreeMap<>();
    private long lastId;

    Table(String database, String name) {
        this.database = database;
        this.name = name;
    }

    /** @return the table name */
    public String name() {
        return name;
    }

    /**
     * Inserts a row.
     *
     * @param values column values; {@code "id"} is reserved
     * @return the generated id
     * @throws StoreException if the write fails
     */
    public long insert(Map<String, Object> values) {
        Map<String, Object> clean = normalize(values);
        WriteGuards.check(new WriteRequest(database, name, WriteKind.INSERT, lastId + 1, clean, null));
        long id = ++lastId;
        rows.put(id, clean);
        return id;
    }

    /**
     * Returns the row with that id.
     *
     * @param id the row id
     * @return a copy of the row, or empty if there is none
     */
    public Optional<Row> get(long id) {
        Map<String, Object> values = rows.get(id);
        return values == null ? Optional.empty() : Optional.of(new Row(name, id, values));
    }

    /**
     * Returns the rows whose column equals the value, ordered by id.
     *
     * @param column the column name
     * @param value the value to look for; {@code null} finds rows where the column is absent
     * @return copies of the matching rows
     */
    public List<Row> find(String column, Object value) {
        Objects.requireNonNull(column, "column");
        Object wanted = normalizeValue(column, value);
        List<Row> found = new ArrayList<>();
        rows.forEach((id, values) -> {
            if (Objects.equals(values.get(column), wanted)) {
                found.add(new Row(name, id, values));
            }
        });
        return found;
    }

    /** @return copies of all rows, ordered by id */
    public List<Row> all() {
        List<Row> all = new ArrayList<>();
        rows.forEach((id, values) -> all.add(new Row(name, id, values)));
        return all;
    }

    /**
     * Updates the given columns of a row; other columns keep their value. A {@code null} value
     * removes the column.
     *
     * @param id the row id
     * @param values the columns to change
     * @return {@code true} if the row exists and was updated, {@code false} if there is no such row
     * @throws StoreException if the write fails
     */
    public boolean update(long id, Map<String, Object> values) {
        Map<String, Object> existing = rows.get(id);
        if (existing == null) {
            return false;
        }
        Map<String, Object> changes = normalizeAllowingNulls(values);
        WriteGuards.check(new WriteRequest(database, name, WriteKind.UPDATE, id, changes,
                new Row(name, id, existing)));
        Map<String, Object> merged = new TreeMap<>(existing);
        changes.forEach((column, value) -> {
            if (value == null) {
                merged.remove(column);
            } else {
                merged.put(column, value);
            }
        });
        rows.put(id, merged);
        return true;
    }

    /**
     * Deletes a row.
     *
     * @param id the row id
     * @return {@code true} if the row existed
     * @throws StoreException if the write fails
     */
    public boolean delete(long id) {
        Map<String, Object> existing = rows.get(id);
        if (existing == null) {
            return false;
        }
        WriteGuards.check(new WriteRequest(database, name, WriteKind.DELETE, id, Map.of(),
                new Row(name, id, existing)));
        rows.remove(id);
        return true;
    }

    /** @return the number of rows */
    public int count() {
        return rows.size();
    }

    @Override
    public String toString() {
        return "Table[" + database + "." + name + ", " + rows.size() + " rows]";
    }

    private Map<String, Object> normalize(Map<String, Object> values) {
        Map<String, Object> clean = normalizeAllowingNulls(values);
        clean.values().removeIf(Objects::isNull);
        return clean;
    }

    private Map<String, Object> normalizeAllowingNulls(Map<String, Object> values) {
        Objects.requireNonNull(values, "values");
        Map<String, Object> clean = new TreeMap<>();
        values.forEach((column, value) -> {
            Objects.requireNonNull(column, "column name");
            if (column.equals("id")) {
                throw new IllegalArgumentException("column 'id' is reserved in " + name);
            }
            clean.put(column, normalizeValue(column, value));
        });
        return clean;
    }

    private Object normalizeValue(String column, Object value) {
        if (value == null || value instanceof String || value instanceof Long
                || value instanceof Boolean || value instanceof LocalDate) {
            return value;
        }
        if (value instanceof Integer || value instanceof Short || value instanceof Byte) {
            return ((Number) value).longValue();
        }
        throw new IllegalArgumentException("unsupported type " + value.getClass().getSimpleName()
                + " for column '" + column + "' in " + name);
    }
}
