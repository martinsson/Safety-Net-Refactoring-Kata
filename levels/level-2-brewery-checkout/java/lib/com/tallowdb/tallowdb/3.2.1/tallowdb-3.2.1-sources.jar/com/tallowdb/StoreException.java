package com.tallowdb;

/**
 * Thrown when a write cannot be applied. When a write throws, nothing was written by that call;
 * earlier writes stay applied.
 */
public class StoreException extends RuntimeException {

    /** @param message what failed */
    public StoreException(String message) {
        super(message);
    }
}
