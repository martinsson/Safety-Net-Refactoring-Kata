package com.tallowdb;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

/**
 * A named set of tables and sequences. Obtain it with {@link TallowDb#open(String)}.
 *
 * <p>Tables and sequences are created on first use. There are no transactions: every write is
 * applied immediately and stays applied, whatever happens next.
 */
public final class Database {

    private final String name;
    private final Map<String, Table> tables = new LinkedHashMap<>();
    private final Map<String, Long> sequences = new LinkedHashMap<>();

    Database(String name) {
        this.name = name;
    }

    /** @return the name this database was opened with */
    public String name() {
        return name;
    }

    /**
     * Returns the table of that name, creating it empty on first use.
     *
     * @param tableName the table name, not blank
     * @return the same instance for the same name
     */
    public Table table(String tableName) {
        Objects.requireNonNull(tableName, "tableName");
        if (tableName.isBlank()) {
            throw new IllegalArgumentException("table name must not be blank");
        }
        return tables.computeIfAbsent(tableName, t -> new Table(name, t));
    }

    /** @return the names of the tables created so far, in creation order */
    public List<String> tableNames() {
        return new ArrayList<>(tables.keySet());
    }

    /**
     * Draws the next value of a sequence. A new sequence starts at 1. Values drawn are never
     * given back, even if the caller does not use them.
     *
     * @param sequence the sequence name
     * @return the next value
     */
    public long nextValue(String sequence) {
        Objects.requireNonNull(sequence, "sequence");
        long next = sequences.getOrDefault(sequence, 1L);
        sequences.put(sequence, next + 1);
        return next;
    }

    /**
     * Sets the value that the next {@link #nextValue(String)} call returns.
     *
     * @param sequence the sequence name
     * @param next the next value to hand out
     */
    public void restartSequence(String sequence, long next) {
        Objects.requireNonNull(sequence, "sequence");
        sequences.put(sequence, next);
    }

    @Override
    public String toString() {
        return "Database[" + name + "]";
    }
}
