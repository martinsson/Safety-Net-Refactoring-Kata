package com.tallowdb.spi;

import java.util.Objects;

/**
 * Holds the JVM-wide {@link WriteGuard}. There is at most one guard; installing a new one
 * replaces the previous one. The guard applies to every database, including databases opened
 * later, and survives {@code TallowDb.dropAll()}.
 */
public final class WriteGuards {

    private static final WriteGuard NONE = request -> { };
    private static WriteGuard current = NONE;

    private WriteGuards() {
    }

    /**
     * Installs the guard called before every write.
     *
     * @param guard the guard
     */
    public static void install(WriteGuard guard) {
        current = Objects.requireNonNull(guard, "guard");
    }

    /** Removes the installed guard, if any. */
    public static void clear() {
        current = NONE;
    }

    /**
     * Called by TallowDB before applying a write.
     *
     * @param request the write about to be applied
     * @throws com.tallowdb.StoreException if the installed guard refuses the write
     */
    public static void check(WriteRequest request) {
        current.beforeWrite(request);
    }
}
