package com.tallowdb.spi;

/**
 * Hook called before every table write. A guard refuses a write by throwing
 * {@link com.tallowdb.StoreException}; the write is then not applied.
 *
 * <p>Intended for test kits and diagnostics tools. Install it with {@link WriteGuards#install}.
 */
@FunctionalInterface
public interface WriteGuard {

    /**
     * Inspects a write before it is applied.
     *
     * @param request the write about to be applied
     * @throws com.tallowdb.StoreException to refuse the write
     */
    void beforeWrite(WriteRequest request);
}
