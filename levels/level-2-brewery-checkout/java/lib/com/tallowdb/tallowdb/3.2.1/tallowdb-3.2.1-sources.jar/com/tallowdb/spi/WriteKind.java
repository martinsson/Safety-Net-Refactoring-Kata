package com.tallowdb.spi;

/** The kind of a table write. */
public enum WriteKind {
    /** {@code Table.insert}. */
    INSERT,
    /** {@code Table.update}. */
    UPDATE,
    /** {@code Table.delete}. */
    DELETE
}
