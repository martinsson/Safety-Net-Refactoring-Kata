package com.tallowdb;

import java.time.LocalDate;
import java.util.Collections;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.TreeMap;

/**
 * An immutable copy of a table row, with typed getters.
 *
 * <p>{@link #getString(String)}, {@link #getDate(String)} and {@link #get(String)} return
 * {@code null} for an absent column; the primitive getters throw {@link NoSuchElementException}.
 */
public final class Row {

    private final String table;
    private final long id;
    private final Map<String, Object> values;

    Row(String table, long id, Map<String, Object> values) {
        this.table = table;
        this.id = id;
        this.values = Collections.unmodifiableMap(new TreeMap<>(values));
    }

    /** @return the row id */
    public long id() {
        return id;
    }

    /** @return the name of the table the row was read from */
    public String table() {
        return table;
    }

    /** @return whether the column is present */
    public boolean has(String column) {
        return values.containsKey(column);
    }

    /** @return the raw value, or {@code null} if absent */
    public Object get(String column) {
        return values.get(column);
    }

    /** @return the value as a string, or {@code null} if absent */
    public String getString(String column) {
        Object value = values.get(column);
        return value == null ? null : value.toString();
    }

    /** @return the value as a long */
    public long getLong(String column) {
        return typed(column, Long.class);
    }

    /** @return the value as an int */
    public int getInt(String column) {
        return Math.toIntExact(getLong(column));
    }

    /** @return the value as a boolean */
    public boolean getBoolean(String column) {
        return typed(column, Boolean.class);
    }

    /** @return the value as a date, or {@code null} if absent */
    public LocalDate getDate(String column) {
        return values.containsKey(column) ? typed(column, LocalDate.class) : null;
    }

    /** @return all column values, sorted by column name (the id is not included) */
    public Map<String, Object> values() {
        return values;
    }

    private <T> T typed(String column, Class<T> type) {
        Object value = values.get(column);
        if (value == null) {
            throw new NoSuchElementException("no column '" + column + "' in " + table + "#" + id);
        }
        if (!type.isInstance(value)) {
            throw new ClassCastException("column '" + column + "' in " + table + "#" + id
                    + " holds a " + value.getClass().getSimpleName() + ", not a " + type.getSimpleName());
        }
        return type.cast(value);
    }

    @Override
    public boolean equals(Object other) {
        return other instanceof Row row && row.id == id && row.table.equals(table) && row.values.equals(values);
    }

    @Override
    public int hashCode() {
        return Long.hashCode(id) * 31 + values.hashCode();
    }

    /** @return {@code table#id{column=value, ...}}, columns sorted by name */
    @Override
    public String toString() {
        return table + "#" + id + values;
    }
}
